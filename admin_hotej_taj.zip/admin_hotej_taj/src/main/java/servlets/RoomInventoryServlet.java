package servlets;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.*;

@WebServlet("/RoomInventoryServlet")
public class RoomInventoryServlet extends HttpServlet {

    private final String jdbcURL = "jdbc:mysql://localhost:3306/hotel taj?useSSL=false&serverTimezone=UTC";
    private final String dbUser = "root";
    private final String dbPassword = "";

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            throw new ServletException("JDBC Driver not found.", e);
        }

        try (Connection conn = DriverManager.getConnection(jdbcURL, dbUser, dbPassword)) {
            if ("add".equalsIgnoreCase(action)) {
                String roomNumber = request.getParameter("room_number");
                int roomTypeId = Integer.parseInt(request.getParameter("room_type_id"));
                String status = request.getParameter("status");
                String cleanStatus = request.getParameter("clean_status");

                try (PreparedStatement ps = conn.prepareStatement(
                        "INSERT INTO room_inventory (room_number, room_type_id, status) VALUES (?, ?, ?)",
                        Statement.RETURN_GENERATED_KEYS)) {
                    ps.setString(1, roomNumber);
                    ps.setInt(2, roomTypeId);
                    ps.setString(3, status);
                    ps.executeUpdate();

                    try (ResultSet rs = ps.getGeneratedKeys()) {
                        if (rs.next()) {
                            int roomId = rs.getInt(1);
                            try (PreparedStatement ps2 = conn.prepareStatement(
                                    "INSERT INTO rooms_status (room_id, status) VALUES (?, ?)")) {
                                ps2.setInt(1, roomId);
                                ps2.setString(2, cleanStatus);
                                ps2.executeUpdate();
                            }
                        }
                    }
                }
            } else if ("update".equalsIgnoreCase(action)) {
                int id = Integer.parseInt(request.getParameter("id"));
                String roomNumber = request.getParameter("room_number");
                int roomTypeId = Integer.parseInt(request.getParameter("room_type_id"));
                String status = request.getParameter("status");
                String cleanStatus = request.getParameter("clean_status");

                try (PreparedStatement ps = conn.prepareStatement(
                        "UPDATE room_inventory SET room_number=?, room_type_id=?, status=? WHERE id=?")) {
                    ps.setString(1, roomNumber);
                    ps.setInt(2, roomTypeId);
                    ps.setString(3, status);
                    ps.setInt(4, id);
                    ps.executeUpdate();
                }

                try (PreparedStatement ps = conn.prepareStatement(
                        "INSERT INTO rooms_status (room_id, status) VALUES (?, ?) " +
                                "ON DUPLICATE KEY UPDATE status=?, updated_at=CURRENT_TIMESTAMP")) {
                    ps.setInt(1, id);
                    ps.setString(2, cleanStatus);
                    ps.setString(3, cleanStatus);
                    ps.executeUpdate();
                }

            } else if ("delete".equalsIgnoreCase(action)) {
                int id = Integer.parseInt(request.getParameter("id"));


                try (PreparedStatement ps = conn.prepareStatement("DELETE FROM rooms_status WHERE room_id=?")) {
                    ps.setInt(1, id);
                    ps.executeUpdate();
                }

                try (PreparedStatement ps = conn.prepareStatement("DELETE FROM room_inventory WHERE id=?")) {
                    ps.setInt(1, id);
                    ps.executeUpdate();
                }
            }
        } catch (SQLException e) {
            throw new ServletException(e);
        }

        response.sendRedirect("listRooms.jsp");
    }
}
