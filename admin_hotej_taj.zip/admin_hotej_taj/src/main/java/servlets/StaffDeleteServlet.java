package servlets;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;

@WebServlet("/StaffDeleteServlet")
public class StaffDeleteServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int id = Integer.parseInt(request.getParameter("id"));

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel taj", "root", "");
                 PreparedStatement ps = con.prepareStatement("DELETE FROM staff WHERE id = ?")) {

                ps.setInt(1, id);
                ps.executeUpdate();
            }

            response.sendRedirect("staff.jsp");

        } catch (Exception e) {
            e.printStackTrace();
            response.setContentType("text/html;charset=UTF-8");
            try (PrintWriter out = response.getWriter()) {
                out.println("<h3>Error: " + e.getMessage() + "</h3>");
            }
        }
    }
}
