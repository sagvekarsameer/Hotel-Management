package servlets;

import java.io.*;
import java.nio.file.*;
import javax.servlet.*;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.*;
import java.sql.*;
import org.mindrot.jbcrypt.BCrypt;

@MultipartConfig
public class StaffRegistrationServlet extends HttpServlet {
    private static final String IMAGE_UPLOAD_DIR = "staff_photos";

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String phone = request.getParameter("phone");
        String department = request.getParameter("department");
        String designation = request.getParameter("designation");
        String shiftType = request.getParameter("shift_type");
        String bio = request.getParameter("bio");
        String password = request.getParameter("password");

        // Handle file upload
        Part photoPart = request.getPart("photo");
        String fileName = (photoPart != null) ? Paths.get(photoPart.getSubmittedFileName()).getFileName().toString() : "";
        String photoPath = null;

        if (fileName != null && !fileName.isEmpty()) {
            String uploadPath = getServletContext().getRealPath("") + File.separator + IMAGE_UPLOAD_DIR;
            File uploadDir = new File(uploadPath);
            if (!uploadDir.exists()) uploadDir.mkdir();
            photoPath = IMAGE_UPLOAD_DIR + File.separator + fileName;
            photoPart.write(uploadPath + File.separator + fileName);
        }

        try {
            // Hash password
            String hashedPwd = BCrypt.hashpw(password, BCrypt.gensalt());

            // Connect to DB
            Class.forName("com.mysql.cj.jdbc.Driver");
            try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel taj", "root", "");
                 PreparedStatement ps = con.prepareStatement(
                         "INSERT INTO staff (name, email, phone, department, designation, shift_type, bio, photo, password) " +
                                 "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)")) {

                ps.setString(1, name);
                ps.setString(2, email);
                ps.setString(3, phone);
                ps.setString(4, department);
                ps.setString(5, designation);
                ps.setString(6, shiftType);
                ps.setString(7, bio);
                ps.setString(8, photoPath);
                ps.setString(9, hashedPwd);

                ps.executeUpdate();
            }

            response.sendRedirect("staff.jsp");

        } catch (Exception e) {
            e.printStackTrace();
            response.setContentType("text/html;charset=UTF-8");
            try (PrintWriter out = response.getWriter()) {
                out.println("<h3>Error: " + e.getMessage() + "</h3>");
            }
        }
    }
}
