package servlets;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;

public class AdminUpdatePasswordServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String newPassword = request.getParameter("new_password");
        int adminId = (Integer) request.getSession().getAttribute("admin_id");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel taj", "root", "");
            PreparedStatement ps = con.prepareStatement("UPDATE admin SET password=? WHERE id=?");
            ps.setString(1, newPassword); // You should hash it in real apps
            ps.setInt(2, adminId);
            ps.executeUpdate();
            con.close();
        } catch(Exception e) {
            e.printStackTrace();
        }

        response.sendRedirect("admin_profile.jsp");
    }
}
