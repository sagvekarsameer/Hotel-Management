package servlets;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.*;

@WebServlet("/AdminLoginServlet")
public class AdminLoginServlet extends HttpServlet {

    // Database config
    private static final String DB_URL = "jdbc:mysql://localhost:3306/hotel taj";
    private static final String DB_USER = "root";
    private static final String DB_PASS = "";

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String userEmail = request.getParameter("username");
        String password = request.getParameter("password");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            try (Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS)) {
                String sql = "SELECT * FROM admin_users WHERE email = ? AND password = ?";
                PreparedStatement ps = con.prepareStatement(sql);
                ps.setString(1, userEmail);
                ps.setString(2, password);

                ResultSet rs = ps.executeQuery();

                if (rs.next()) {

                    HttpSession session = request.getSession();
                    session.setAttribute("admin", userEmail);
                    session.setMaxInactiveInterval(2 * 60 * 60); // 2 hours

                    response.sendRedirect("admin_dashboard.jsp");
                } else {

                    response.sendRedirect("index.jsp?error=Invalid+credentials");
                }

                rs.close();
                ps.close();
            }

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("index.jsp?error=Something+went+wrong");
        }
    }
}
