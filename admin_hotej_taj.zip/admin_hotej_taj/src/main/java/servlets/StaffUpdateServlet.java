package servlets;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;

@WebServlet("/StaffUpdateServlet")
public class StaffUpdateServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        int id = Integer.parseInt(request.getParameter("id"));
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String phone = request.getParameter("phone");
        String department = request.getParameter("department");
        String designation = request.getParameter("designation");
        String shiftType = request.getParameter("shift_type");
        String bio = request.getParameter("bio");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel taj", "root", "");
                 PreparedStatement ps = con.prepareStatement(
                         "UPDATE staff SET name=?, email=?, phone=?, department=?, designation=?, shift_type=?, bio=? WHERE id=?")) {

                ps.setString(1, name);
                ps.setString(2, email);
                ps.setString(3, phone);
                ps.setString(4, department);
                ps.setString(5, designation);
                ps.setString(6, shiftType);
                ps.setString(7, bio);
                ps.setInt(8, id);

                ps.executeUpdate();
            }

            response.sendRedirect("staff.jsp");

        } catch (Exception e) {
            e.printStackTrace();
            response.setContentType("text/html;charset=UTF-8");
            try (PrintWriter out = response.getWriter()) {
                out.println("<h3>Error: " + e.getMessage() + "</h3>");
            }
        }
    }
}
