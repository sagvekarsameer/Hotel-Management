package servlets;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;

public class UpdateUserStatusServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int userId = Integer.parseInt(request.getParameter("user_id"));
        String action = request.getParameter("action");
        String newStatus = action.equals("Block") ? "BLOCKED" : "ACTIVE";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel taj", "root", "");
            PreparedStatement ps = con.prepareStatement("UPDATE users SET status=? WHERE id=?");
            ps.setString(1, newStatus);
            ps.setInt(2, userId);
            ps.executeUpdate();
            con.close();
        } catch(Exception e) {
            e.printStackTrace();
        }

        response.sendRedirect("defaulters.jsp");
    }
}
