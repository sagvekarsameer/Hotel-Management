package org.example;

import java.sql.*;
import java.util.*;

public class ImageDAO {
    public static List<Image> getAllImages() {
        List<Image> list = new ArrayList<>();
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/hotel taj", "root", "");

            String sql = "SELECT placeName, imageUrl FROM gallery";
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                list.add(new Image(rs.getString("placeName"), rs.getString("imageUrl")));
            }

            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
}
