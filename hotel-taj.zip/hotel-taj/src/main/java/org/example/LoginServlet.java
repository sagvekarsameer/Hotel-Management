package org.example;

import org.mindrot.jbcrypt.BCrypt;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.*;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {

    private static final String DB_URL = "jdbc:mysql://localhost:3306/hotel taj";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "";

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String email = request.getParameter("email");
        String password = request.getParameter("password");

        try {
            // Load JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Create connection
            try (
                    Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
                    PreparedStatement stmt = conn.prepareStatement("SELECT * FROM users WHERE email = ?")
            ) {
                stmt.setString(1, email);

                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                        String storedHashedPassword = rs.getString("password");

                        if (BCrypt.checkpw(password, storedHashedPassword)) {
                            // Password match: create session
                            HttpSession session = request.getSession();
                            session.setAttribute("email", rs.getString("email"));
                            session.setAttribute("full_name", rs.getString("full_name"));

                            response.sendRedirect("index.jsp");
                        } else {
                            // Incorrect password
                            request.setAttribute("errorMessage", "Invalid password!");
                            request.getRequestDispatcher("login.jsp").forward(request, response);
                        }
                    } else {
                        // User not found
                        request.setAttribute("errorMessage", "User not found!");
                        request.getRequestDispatcher("login.jsp").forward(request, response);
                    }
                }
            }
        } catch (Exception e) {
            request.setAttribute("errorMessage", "Error: " + e.getMessage());
            request.getRequestDispatcher("login.jsp").forward(request, response);
        }
    }
}
