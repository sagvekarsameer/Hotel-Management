package org.example;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/check-login")
public class CheckLoginServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        String roomId = request.getParameter("roomId");

        if (session != null && session.getAttribute("email") != null) {
            // Logged in
            response.sendRedirect("booking.jsp?roomId=" + roomId);
        } else {
            // Not logged in
            session = request.getSession(true); // create new if none
            session.setAttribute("redirectAfterLogin", "booking.jsp?roomId=" + roomId);
            response.sendRedirect("login.jsp");
        }
    }
}
