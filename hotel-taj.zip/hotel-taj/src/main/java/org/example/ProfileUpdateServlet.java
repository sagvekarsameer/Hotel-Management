package org.example;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.*;
import java.sql.*;

@WebServlet("/ProfileUpdateServlet")
@MultipartConfig(fileSizeThreshold = 1024 * 1024, // 1MB
        maxFileSize = 5 * 1024 * 1024,    // 5MB
        maxRequestSize = 10 * 1024 * 1024) // 10MB
public class ProfileUpdateServlet extends HttpServlet {

    private static final String DB_URL = "jdbc:mysql://localhost:3306/hotel taj";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "";
    private static final String UPLOAD_DIR = "uploads";

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        String email = (String) session.getAttribute("email");
        if (email == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        request.setCharacterEncoding("UTF-8");

        String name = request.getParameter("name");
        String phone = request.getParameter("phone");
        String address = request.getParameter("address");
        String city = request.getParameter("city");
        String idType = request.getParameter("id_card_type");
        String idNumber = request.getParameter("id_card_number");

        // Handle file uploads
        Part frontPart = request.getPart("id_image_front");
        Part backPart = request.getPart("id_image_back");

        String frontFileName = getFileName(frontPart);
        String backFileName = getFileName(backPart);

        String appPath = request.getServletContext().getRealPath("");
        String uploadPath = appPath + File.separator + UPLOAD_DIR;
        new File(uploadPath).mkdirs(); // Create uploads folder if not exists

        if (!frontFileName.isEmpty()) {
            frontPart.write(uploadPath + File.separator + frontFileName);
        }

        if (!backFileName.isEmpty()) {
            backPart.write(uploadPath + File.separator + backFileName);
        }

        // Database update
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            StringBuilder query = new StringBuilder("UPDATE users SET full_name=?, phone_number=?, address=?, city=?, id_card_type=?, id_card_number=?");
            if (!frontFileName.isEmpty()) query.append(", id_image_front=?");
            if (!backFileName.isEmpty()) query.append(", id_image_back=?");
            query.append(" WHERE email=?");

            PreparedStatement ps = conn.prepareStatement(query.toString());

            ps.setString(1, name);
            ps.setString(2, phone);
            ps.setString(3, address);
            ps.setString(4, city);
            ps.setString(5, idType);
            ps.setString(6, idNumber);

            int index = 7;
            if (!frontFileName.isEmpty()) {
                ps.setString(index++, frontFileName);
            }
            if (!backFileName.isEmpty()) {
                ps.setString(index++, backFileName);
            }

            ps.setString(index, email);

            int result = ps.executeUpdate();
            ps.close();
            conn.close();

            if (result > 0) {
                response.sendRedirect("profile.jsp");
            } else {
                response.getWriter().println("Update failed.");
            }

        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("Error: " + e.getMessage());
        }
    }

    private String getFileName(Part part) {
        String contentDisp = part.getHeader("content-disposition");
        if (contentDisp != null && contentDisp.contains("filename=")) {
            for (String token : contentDisp.split(";")) {
                if (token.trim().startsWith("filename")) {
                    return token.substring(token.indexOf("=") + 2, token.length() - 1);
                }
            }
        }
        return "";
    }
}
