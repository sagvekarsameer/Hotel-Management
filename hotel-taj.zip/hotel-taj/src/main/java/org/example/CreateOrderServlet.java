package org.example;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;
import java.util.UUID;
import com.razorpay.*;
import org.json.JSONObject;

@WebServlet("/CreateOrderServlet")
public class CreateOrderServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // 1. Fetch form data
        String email = (String) request.getSession().getAttribute("email");
        String roomId = request.getParameter("roomId");
        String amountStr = request.getParameter("amount");
        int amount = Integer.parseInt(amountStr); // in paise

        String phone = request.getParameter("customerPhone");
        String address = request.getParameter("customerAddress");
        String city = request.getParameter("customerCity");

        String checkIn = request.getParameter("checkInDate");
        String checkOut = request.getParameter("checkOutDate");
        int numGuests = Integer.parseInt(request.getParameter("numGuests"));
        String specialRequests = request.getParameter("specialRequests");

        String idCardType = request.getParameter("idCardType");
        String idCardNumber = request.getParameter("idCardNumber");

        String fullName = "", roomName = "", roomImage = "";
        double roomPrice = 0;

        String bookingId = "BK" + System.currentTimeMillis();

        try {
            // 2. Load MySQL driver & connect
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel taj", "root", "");

            // 3. Fetch user and room details
            PreparedStatement userStmt = conn.prepareStatement("SELECT full_name FROM users WHERE email = ?");
            userStmt.setString(1, email);
            ResultSet userRs = userStmt.executeQuery();
            if (userRs.next()) {
                fullName = userRs.getString("full_name");
            }

            PreparedStatement roomStmt = conn.prepareStatement("SELECT name, price, image FROM rooms WHERE id = ?");
            roomStmt.setInt(1, Integer.parseInt(roomId));
            ResultSet roomRs = roomStmt.executeQuery();
            if (roomRs.next()) {
                roomName = roomRs.getString("name");
                roomPrice = roomRs.getDouble("price");
                roomImage = roomRs.getString("image");
            }

            // 4. Save booking to DB with 'PENDING' status
            PreparedStatement insertStmt = conn.prepareStatement(
                    "INSERT INTO bookings (id, email, full_name, phone, address, city, room_id, room_name, room_image, room_price, check_in, check_out, num_guests, special_requests, id_card_type, id_card_number, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
            );
            insertStmt.setString(1, bookingId);
            insertStmt.setString(2, email);
            insertStmt.setString(3, fullName);
            insertStmt.setString(4, phone);
            insertStmt.setString(5, address);
            insertStmt.setString(6, city);
            insertStmt.setInt(7, Integer.parseInt(roomId));
            insertStmt.setString(8, roomName);
            insertStmt.setString(9, roomImage);
            insertStmt.setDouble(10, roomPrice);
            insertStmt.setString(11, checkIn);
            insertStmt.setString(12, checkOut);
            insertStmt.setInt(13, numGuests);
            insertStmt.setString(14, specialRequests);
            insertStmt.setString(15, idCardType);
            insertStmt.setString(16, idCardNumber);
            insertStmt.setString(17, "PENDING");

            insertStmt.executeUpdate();

            // 5. Razorpay Order creation
            RazorpayClient razorpay = new RazorpayClient("rzp_test_zNd6yTKVltKNht", "gz0SMkza5v5Hk5en7tsCqJTy");

            JSONObject orderRequest = new JSONObject();
            orderRequest.put("amount", amount);
            orderRequest.put("currency", "INR");
            orderRequest.put("receipt", bookingId);
            orderRequest.put("payment_capture", 1);

            Order order = razorpay.orders.create(orderRequest);

            // 6. Set attributes for Razorpay page
            request.setAttribute("orderId", order.get("id"));
            request.setAttribute("amount", amountStr);
            request.setAttribute("key", "rzp_test_zNd6yTKVltKNht");
            request.setAttribute("customerName", fullName);
            request.setAttribute("customerEmail", email);
            request.setAttribute("customerPhone", phone);
            request.setAttribute("bookingId", bookingId);

            // 7. Forward to Razorpay payment page
            RequestDispatcher rd = request.getRequestDispatcher("razorpay-checkout.jsp");
            rd.forward(request, response);

        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().write("Error: " + e.getMessage());
        }
    }
}
